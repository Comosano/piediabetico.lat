"""
╔══════════════════════════════════════════════════════════════════════╗
║  AGENTE 7 — TRIAGE MULTIMODAL CON IA                               ║
║  piediabetico.lat — Versión 1.0.0                                   ║
╠══════════════════════════════════════════════════════════════════════╣
║  Tecnología: Claude Vision API (claude-sonnet-4-6)                  ║
║  Perfiles:   paciente / podologo_enfermero / infectologo /          ║
║              diabetologo / medico_general                           ║
║                                                                     ║
║  Cómo funciona:                                                     ║
║  1. Recibe una foto de la herida (base64) + datos clínicos          ║
║  2. Selecciona el system prompt según el perfil del usuario         ║
║  3. Llama a Claude Vision API con la foto + contexto clínico        ║
║  4. Devuelve el dictamen adaptado al nivel de quien pregunta        ║
║                                                                     ║
║  DISCLAIMER: Herramienta de apoyo clínico. No reemplaza el         ║
║  diagnóstico ni el tratamiento médico profesional.                  ║
╚══════════════════════════════════════════════════════════════════════╝

Uso con Docker:
    Variables de entorno necesarias:
        ANTHROPIC_API_KEY=sk-ant-...

Integración en main.py:
    from agente7_triage_multimodal import router_agente7
    app.include_router(router_agente7)
"""

import os
import logging
import anthropic
import base64
from enum import Enum
from typing import Optional
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────────────────────
# CLIENTE ANTHROPIC
# ─────────────────────────────────────────────────────────────────────

def get_client() -> anthropic.Anthropic:
    api_key = os.getenv("ANTHROPIC_API_KEY")
    if not api_key:
        raise ValueError("Variable de entorno ANTHROPIC_API_KEY no configurada.")
    return anthropic.Anthropic(api_key=api_key)

MODELO = "claude-sonnet-4-6"
MAX_TOKENS = 1200

DISCLAIMER = (
    "⚠️ AVISO CLÍNICO: Este análisis es generado por inteligencia artificial "
    "como herramienta de apoyo educativo. No reemplaza el diagnóstico clínico "
    "ni el criterio del profesional de salud habilitado. Toda decisión terapéutica "
    "debe ser validada por un médico o profesional competente."
)


# ─────────────────────────────────────────────────────────────────────
# SYSTEM PROMPTS POR PERFIL
# ─────────────────────────────────────────────────────────────────────
# Cada perfil tiene su propio system prompt que define:
#   - El rol que asume la IA
#   - El nivel de lenguaje técnico
#   - La estructura de la respuesta
#   - Las prioridades clínicas de ese perfil
# ─────────────────────────────────────────────────────────────────────

SYSTEM_PROMPTS = {

    # ─── PACIENTE ────────────────────────────────────────────────────
    "paciente": """
Sos un asistente de salud especializado en el cuidado del pie diabético.
Hablás directamente con una persona que tiene diabetes y está preocupada por su pie.

TU MISIÓN: Ayudar a la persona a entender qué está viendo en su pie y si necesita
atención médica urgente, con urgencia media, o puede esperar su próxima consulta.

REGLAS DE COMUNICACIÓN:
- Usá lenguaje SIMPLE, sin términos médicos. Si usás alguno, explicalo entre paréntesis.
- Hablá de vos a vos, de forma amable y directa.
- Nunca causes pánico innecesario, pero tampoco minimices señales graves.
- Si hay algo que te preocupa, decilo claramente.
- Máximo 200 palabras. Oraciones cortas.

ESTRUCTURA DE TU RESPUESTA (siempre en este orden):
1. Lo que ves (1-2 oraciones en lenguaje simple)
2. Nivel de urgencia: UNA de estas tres opciones con su ícono:
   🟢 PODÉS ESPERAR — Atendelo en tu próxima consulta programada
   🟡 CONSULTÁ ESTA SEMANA — Llamá a tu médico o podólogo en los próximos días
   🔴 CONSULTÁ HOY — Buscá atención médica hoy mismo
3. Qué hacer ahora (2-3 instrucciones concretas y simples)
4. Una señal de alarma: "Si ves esto, buscá atención urgente: ..."

NUNCA:
- Recetes medicamentos
- Digas diagnósticos definitivos
- Uses palabras como necrosis, esfacelo, isquemia sin explicarlas
- Recomiendes automedicación
""",

    # ─── PODÓLOGO / ENFERMERO ─────────────────────────────────────────
    "podologo_enfermero": """
Sos un asistente clínico especializado en pie diabético trabajando con un podólogo
o enfermero experto en curaciones de heridas crónicas.

TU MISIÓN: Analizar la herida y proporcionar una evaluación clínica estructurada
que apoye la toma de decisiones en el punto de atención.

PERFIL DE USUARIO: Profesional con formación en cuidado de heridas. Conoce la
escala TIMERS, tipos de tejido (granulación, fibrina, esfacelo, necrosis), y
apósitos de uso habitual.

ESTRUCTURA DE TU RESPUESTA:

**EVALUACIÓN DEL LECHO DE LA HERIDA**
- Tejido predominante: [granulación / fibrina / esfacelo / necrosis seca / necrosis húmeda / mixto]
- Estimación visual: % por tipo de tejido si es posible
- Bordes: [activos y migrando / estancados / macerados / enrollados]
- Signos de infección local: [sí/no] — describir hallazgos si los hay
- Exudado aparente: [escaso / moderado / abundante]

**APLICACIÓN TIMERS**
- T (Tejido no viable): [presente/ausente] — conducta sugerida
- I (Infección/Inflamación): [presente/ausente] — nivel estimado
- M (Moisture/Humedad): [adecuada / exceso / déficit]
- E (Edge/Bordes): [activos / estancados]
- R (Repair/Reparación): [hay avance / estancada]
- S (Social factors): [no evaluable por imagen]

**SUGERENCIA DE CONDUCTA**
- Tipo de desbridamiento si aplica
- Apósito recomendado y frecuencia de curación
- Señales de alarma para derivación

**PREGUNTAS CLAVE** (lo que necesitaría saber para completar la evaluación)
Máximo 3 preguntas sobre lo que no puede verse en la foto.

Longitud: 250-350 palabras. Terminología clínica apropiada.
""",

    # ─── INFECTÓLOGO ──────────────────────────────────────────────────
    "infectologo": """
Sos un asistente clínico de infectología especializado en infecciones de pie diabético.
Trabajás con un infectólogo que necesita apoyo para la evaluación de una herida.

TU MISIÓN: Evaluar los signos visuales de infección, estimar la severidad según
la clasificación IDSA, y proporcionar orientación sobre cobertura antibiótica empírica.

PERFIL DE USUARIO: Infectólogo o médico con formación en infectología. Conoce
la clasificación IDSA, microorganismos relevantes (SAMR, Pseudomonas, polimicrobiana),
y los esquemas antibióticos de las guías internacionales.

ESTRUCTURA DE TU RESPUESTA:

**SIGNOS VISUALES DE INFECCIÓN**
- Eritema perilesional: [presente/ausente — extensión estimada en cm si es posible]
- Edema local: [presente/ausente]
- Secreción: [tipo y cantidad si es visible]
- Tejido desvitalizado: [descripción]
- Signos de infección profunda sugestivos: [sí/no]

**CLASIFICACIÓN IDSA ESTIMADA**
[Sin infección / Leve / Moderada / Grave — con justificación]

**FACTORES DE RIESGO PARA MICROORGANISMOS RESISTENTES**
(basado en los datos clínicos proporcionados, no en la imagen)
- Sospecha de SAMR: [sí/no/posible]
- Sospecha de Pseudomonas: [sí/no/posible]
- Polimicrobiana probable: [sí/no]

**ORIENTACIÓN DE COBERTURA EMPÍRICA SUGERIDA**
(referencia educativa — ajustar según cultivos, epidemiología local y función renal)
- Esquema de primera línea sugerido
- Alternativa si hay alergia a beta-lactámicos
- Consideraciones de ajuste renal si los datos lo indican

**DATOS FALTANTES CRÍTICOS**
Lo que necesitaría para una evaluación completa:
cultivos, laboratorio, imagen ósea, etc.

**SEÑALES DE INTERNACIÓN URGENTE**
[Criterios IDSA para hospitalización si se observan]

Longitud: 300-400 palabras. Terminología infectológica precisa.
""",

    # ─── DIABETÓLOGO ─────────────────────────────────────────────────
    "diabetologo": """
Sos un asistente clínico especializado en el manejo integral del pie diabético.
Trabajás con un diabetólogo que tiene acceso completo al historial del paciente.

TU MISIÓN: Integrar los hallazgos de la imagen con el contexto metabólico y clínico
del paciente para apoyar una visión integral de la úlcera y su pronóstico.

PERFIL DE USUARIO: Diabetólogo especializado en complicaciones. Conoce la
clasificación IWGDF, Wagner, Texas, el impacto del control glucémico en la
cicatrización, y la evaluación vascular y neuropática.

ESTRUCTURA DE TU RESPUESTA:

**CARACTERIZACIÓN DE LA ÚLCERA**
- Localización anatómica estimada: [antepié / mediopié / talón / digital / dorsal]
- Etiología probable: [neuropática / isquémica / neuroisquémica / otra]
- Profundidad estimada: [superficial / profunda / con exposición tendinosa/ósea posible]
- Clasificación Wagner estimada: [0-5 con justificación]
- Clasificación Texas si aplica: [grado/estadio]

**ANÁLISIS DEL LECHO**
- Estado del tejido de granulación
- Presencia de tejido desvitalizado
- Estimación de la fase de cicatrización

**CORRELACIÓN METABÓLICA**
(basado en los datos clínicos proporcionados)
- Impacto probable del control glucémico en la evolución
- Consideraciones sobre HbA1c y velocidad de cicatrización
- Factores metabólicos que modifican el pronóstico

**EVALUACIÓN DE RIESGO IWGDF**
- Grupo de riesgo estimado: [0-3]
- Factores determinantes identificados

**PLAN INTEGRAL SUGERIDO**
- Prioridades de manejo (vascular, infeccioso, metabólico, descarga)
- Indicación de estudios complementarios sugeridos
- Criterios de derivación urgente si aplica

**PRONÓSTICO ESTIMADO**
Factores favorables y desfavorables para la cicatrización basados en
la imagen y el contexto clínico.

Longitud: 350-450 palabras. Visión integral e integradora.
""",

    # ─── MÉDICO GENERAL ──────────────────────────────────────────────
    "medico_general": """
Sos un asistente clínico de apoyo para médicos generales o de atención primaria
que atienden pacientes diabéticos con complicaciones en el pie.

TU MISIÓN: Proporcionar una evaluación clara y accionable de la herida, con énfasis
en identificar señales de alarma y orientar la derivación al especialista correcto.

PERFIL DE USUARIO: Médico con formación general, sin especialización en pie diabético.
Puede no conocer escalas específicas como TIMERS o la clasificación Texas, pero
sí entiende terminología médica básica.

ESTRUCTURA DE TU RESPUESTA:

**QUÉ VEO EN LA IMAGEN**
Descripción clara de la herida en términos médicos generales (2-3 oraciones).

**NIVEL DE PREOCUPACIÓN**
🟢 BAJO — Manejo en atención primaria, seguimiento habitual
🟡 MODERADO — Derivación a podología o equipo de pie diabético en los próximos días
🔴 ALTO — Derivación urgente hoy / evaluación hospitalaria

**SEÑALES DE ALARMA PRESENTES** (si las hay)
Lista puntual de lo que motiva el nivel de preocupación.

**ACCIÓN INMEDIATA RECOMENDADA**
- Qué hacer ahora con el paciente
- A qué especialista derivar y con qué urgencia
- Qué información enviar con la derivación

**MIENTRAS LLEGA LA CONSULTA**
Instrucciones de cuidado básico para el médico general
y para transmitirle al paciente.

**NO OLVIDAR PREGUNTAR**
3 datos clínicos clave para completar la evaluación
(pulsos, sensibilidad, control glucémico, etc.)

Longitud: 200-300 palabras. Claro, directo, accionable.
""",
}


# ─────────────────────────────────────────────────────────────────────
# SCHEMAS PYDANTIC
# ─────────────────────────────────────────────────────────────────────

class PerfilUsuario(str, Enum):
    PACIENTE           = "paciente"
    PODOLOGO_ENFERMERO = "podologo_enfermero"
    INFECTOLOGO        = "infectologo"
    DIABETOLOGO        = "diabetologo"
    MEDICO_GENERAL     = "medico_general"


class DatosClinicosContexto(BaseModel):
    """
    Contexto clínico del paciente para enriquecer el análisis de IA.
    Todos los campos son opcionales — más datos = mejor análisis.
    """
    localizacion_ulcera:     Optional[str]   = Field(None, description="Ej: antepié plantar derecho")
    tiempo_evolucion:        Optional[str]   = Field(None, description="Ej: 3 semanas, 2 meses")
    diabetes_tipo:           Optional[str]   = Field(None, description="Tipo 1 / Tipo 2 / otro")
    hba1c:                   Optional[float] = Field(None, ge=4.0, le=20.0, description="HbA1c en %")
    creatinina:              Optional[float] = Field(None, ge=0.2, le=15.0, description="Creatinina en mg/dL")
    fiebre:                  Optional[bool]  = Field(None, description="¿Tiene fiebre?")
    pulsos_presentes:        Optional[bool]  = Field(None, description="¿Pulsos pedios y tibiales presentes?")
    sensibilidad_conservada: Optional[bool]  = Field(None, description="¿Monofilamento 10g normal?")
    antibioticos_previos:    Optional[bool]  = Field(None, description="¿Recibió antibióticos en las últimas 4 semanas?")
    hospitalizacion_previa:  Optional[bool]  = Field(None, description="¿Hospitalización en el último año?")
    # Cuestionario post-foto (inspirado en Curapp)
    olor_presente:           Optional[bool]  = Field(None, description="¿La herida tiene mal olor?")
    exudado_cantidad:        Optional[str]   = Field(None, description="ninguno / escaso / moderado / abundante")
    dolor_en_herida:         Optional[bool]  = Field(None, description="¿Siente dolor en la herida?")
    nota_libre:              Optional[str]   = Field(None, max_length=500, description="Observación adicional del profesional")


class TriageInput(BaseModel):
    imagen_base64: str = Field(
        ...,
        description="Imagen de la herida codificada en base64 (JPEG o PNG). "
                    "Máximo recomendado: 4MB. Resolución mínima: 640x480px."
    )
    perfil_usuario: PerfilUsuario = Field(
        ...,
        description="Perfil del usuario que realiza la consulta. "
                    "Determina el nivel de lenguaje y la estructura de la respuesta."
    )
    datos_clinicos: DatosClinicosContexto = Field(
        default_factory=DatosClinicosContexto,
        description="Contexto clínico del paciente. Cuantos más datos, mejor el análisis."
    )
    imagen_mime_type: str = Field(
        default="image/jpeg",
        description="Tipo MIME de la imagen: image/jpeg o image/png"
    )


class TriageOutput(BaseModel):
    perfil_consultado:  str
    analisis_ia:        str  = Field(..., description="Análisis completo generado por Claude Vision")
    tokens_utilizados:  int  = Field(..., description="Tokens consumidos en la llamada a la API")
    modelo_utilizado:   str  = Field(..., description="Versión del modelo de IA utilizado")
    disclaimer:         str  = Field(..., description="Aviso clínico obligatorio")


# ─────────────────────────────────────────────────────────────────────
# CONSTRUCTOR DEL USER PROMPT
# ─────────────────────────────────────────────────────────────────────

def _construir_user_prompt(perfil: PerfilUsuario, datos: DatosClinicosContexto) -> str:
    """
    Construye el mensaje de usuario con el contexto clínico disponible.
    Solo incluye los campos que tienen valor para no inflar el prompt.
    """
    lineas = ["Analizá esta imagen de una herida en el pie de un paciente diabético."]

    ctx = []

    if datos.localizacion_ulcera:
        ctx.append(f"Localización: {datos.localizacion_ulcera}")
    if datos.tiempo_evolucion:
        ctx.append(f"Tiempo de evolución: {datos.tiempo_evolucion}")
    if datos.diabetes_tipo:
        ctx.append(f"Tipo de diabetes: {datos.diabetes_tipo}")
    if datos.hba1c is not None:
        ctx.append(f"HbA1c: {datos.hba1c}%")
    if datos.creatinina is not None:
        ctx.append(f"Creatinina sérica: {datos.creatinina} mg/dL")
    if datos.fiebre is not None:
        ctx.append(f"Fiebre: {'Sí' if datos.fiebre else 'No'}")
    if datos.pulsos_presentes is not None:
        ctx.append(f"Pulsos pedios y tibiales: {'Presentes' if datos.pulsos_presentes else 'Ausentes o débiles'}")
    if datos.sensibilidad_conservada is not None:
        ctx.append(f"Monofilamento 10g: {'Normal' if datos.sensibilidad_conservada else 'Alterado'}")
    if datos.antibioticos_previos is not None and datos.antibioticos_previos:
        ctx.append("Recibió antibióticos en las últimas 4 semanas")
    if datos.hospitalizacion_previa is not None and datos.hospitalizacion_previa:
        ctx.append("Hospitalización en el último año")
    if datos.olor_presente is not None:
        ctx.append(f"Mal olor en la herida: {'Sí' if datos.olor_presente else 'No'}")
    if datos.exudado_cantidad:
        ctx.append(f"Exudado: {datos.exudado_cantidad}")
    if datos.dolor_en_herida is not None:
        ctx.append(f"Dolor en la herida: {'Sí' if datos.dolor_en_herida else 'No'}")
    if datos.nota_libre:
        ctx.append(f"Nota del profesional: {datos.nota_libre}")

    if ctx:
        lineas.append("\nDATO CLÍNICOS DISPONIBLES:")
        for item in ctx:
            lineas.append(f"• {item}")

    lineas.append(
        "\nPor favor, respondé siguiendo exactamente la estructura definida "
        "para este perfil de usuario."
    )

    return "\n".join(lineas)


# ─────────────────────────────────────────────────────────────────────
# FUNCIÓN PRINCIPAL DE INFERENCIA
# ─────────────────────────────────────────────────────────────────────

def ejecutar_triage(datos: TriageInput) -> TriageOutput:
    """
    Llama a Claude Vision API con la imagen y el contexto clínico.
    Selecciona automáticamente el system prompt según el perfil.
    """
    # Validar que el perfil tiene system prompt
    perfil_key = datos.perfil_usuario.value
    if perfil_key not in SYSTEM_PROMPTS:
        raise ValueError(f"Perfil '{perfil_key}' no tiene system prompt configurado.")

    # Validar imagen base64 mínimamente
    try:
        imagen_bytes = base64.b64decode(datos.imagen_base64)
        if len(imagen_bytes) < 1000:
            raise ValueError("La imagen parece demasiado pequeña o corrupta.")
        if len(imagen_bytes) > 10_000_000:  # 10MB límite
            raise ValueError("La imagen supera el límite de 10MB.")
    except Exception as e:
        raise ValueError(f"Error al decodificar la imagen: {str(e)}")

    # Construir el mensaje de usuario con contexto clínico
    user_prompt = _construir_user_prompt(datos.perfil_usuario, datos.datos_clinicos)

    # Llamar a Claude Vision API
    client = get_client()

    try:
        respuesta = client.messages.create(
            model=MODELO,
            max_tokens=MAX_TOKENS,
            system=SYSTEM_PROMPTS[perfil_key],
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": datos.imagen_mime_type,
                                "data": datos.imagen_base64,
                            },
                        },
                        {
                            "type": "text",
                            "text": user_prompt,
                        },
                    ],
                }
            ],
        )
    except anthropic.APIStatusError as e:
        logger.error(f"[Agente 7] Error de API Anthropic: {e.status_code} — {e.message}")
        raise HTTPException(
            status_code=502,
            detail=f"Error al conectar con la IA: {e.message}"
        )
    except anthropic.APIConnectionError as e:
        logger.error(f"[Agente 7] Error de conexión con Anthropic: {e}")
        raise HTTPException(
            status_code=503,
            detail="No se pudo conectar con el servicio de IA. Intentá de nuevo."
        )

    # Extraer texto de la respuesta
    texto_respuesta = ""
    for bloque in respuesta.content:
        if bloque.type == "text":
            texto_respuesta += bloque.text

    tokens_usados = respuesta.usage.input_tokens + respuesta.usage.output_tokens

    logger.info(
        f"[Agente 7] Triage completado — perfil: {perfil_key}, "
        f"tokens: {tokens_usados}"
    )

    return TriageOutput(
        perfil_consultado=perfil_key,
        analisis_ia=texto_respuesta,
        tokens_utilizados=tokens_usados,
        modelo_utilizado=MODELO,
        disclaimer=DISCLAIMER,
    )


# ─────────────────────────────────────────────────────────────────────
# ROUTER FASTAPI (para incluir en main.py)
# ─────────────────────────────────────────────────────────────────────

router_agente7 = APIRouter(prefix="/agentes", tags=["Agente 7 — Triage Multimodal IA"])


@router_agente7.post(
    "/triage-multimodal",
    response_model=TriageOutput,
    summary="Agente 7 — Triage Multimodal con Claude Vision",
)
def api_triage_multimodal(datos: TriageInput):
    """
    **Agente 7 — Triage Multimodal con IA**

    Analiza una fotografía de una herida de pie diabético combinada con
    datos clínicos del paciente, y genera un dictamen adaptado al perfil
    del profesional que consulta.

    **Perfiles disponibles:**
    - `paciente` — Lenguaje simple, nivel de urgencia claro (🟢🟡🔴)
    - `podologo_enfermero` — Evaluación TIMERS, apósitos, conducta de curación
    - `infectologo` — Clasificación IDSA, cobertura empírica, señales de internación
    - `diabetologo` — Wagner, IWGDF, correlación metabólica, pronóstico integral
    - `medico_general` — Evaluación clara, derivación, señales de alarma

    **Requisitos de la imagen:**
    - Formato: JPEG o PNG en base64
    - Tamaño mínimo: 640x480 px
    - Tamaño máximo: 10 MB
    - Recomendado: buena iluminación, fondo claro, sin filtros

    **Cuestionario post-foto (opcional pero recomendado):**
    Completar `datos_clinicos` mejora significativamente la calidad del análisis.
    Incluir al menos: localización, tiempo de evolución, presencia de fiebre y olor.

    **Disclaimer:** Herramienta de referencia clínica. No reemplaza el diagnóstico médico.
    """
    try:
        return ejecutar_triage(datos)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"[Agente 7] Error inesperado: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="Error interno del servidor.")


@router_agente7.get(
    "/triage-multimodal/perfiles",
    summary="Listar perfiles disponibles del Agente 7",
)
def listar_perfiles():
    """
    Devuelve los perfiles disponibles y una descripción de cada uno.
    """
    return {
        "perfiles": {
            "paciente": "Análisis en lenguaje simple con nivel de urgencia (🟢🟡🔴) para el propio paciente",
            "podologo_enfermero": "Evaluación TIMERS completa con sugerencia de apósitos y conducta de curación",
            "infectologo": "Clasificación IDSA, orientación de cobertura antibiótica empírica y criterios de internación",
            "diabetologo": "Evaluación integral: Wagner, IWGDF, correlación metabólica y pronóstico",
            "medico_general": "Evaluación clara con señales de alarma y orientación de derivación",
        },
        "nota": (
            "El perfil determina el system prompt utilizado, el nivel de lenguaje técnico "
            "y la estructura de la respuesta. El modelo de IA es el mismo para todos los perfiles."
        ),
        "modelo": MODELO,
        "disclaimer": DISCLAIMER,
    }


# ─────────────────────────────────────────────────────────────────────
# INSTRUCCIONES DE INTEGRACIÓN EN main.py
# ─────────────────────────────────────────────────────────────────────
# 
# Agregar al inicio de main.py:
#
#   from agente7_triage_multimodal import router_agente7
#
# Agregar después de crear la instancia de FastAPI:
#
#   app.include_router(router_agente7)
#
# El endpoint queda disponible en:
#
#   POST /agentes/triage-multimodal
#   GET  /agentes/triage-multimodal/perfiles
#
# ─────────────────────────────────────────────────────────────────────
#
# EJEMPLO DE LLAMADA (Python):
#
#   import requests, base64
#
#   with open("foto_herida.jpg", "rb") as f:
#       imagen_b64 = base64.b64encode(f.read()).decode()
#
#   respuesta = requests.post(
#       "http://localhost:8000/agentes/triage-multimodal",
#       json={
#           "imagen_base64": imagen_b64,
#           "perfil_usuario": "podologo_enfermero",
#           "datos_clinicos": {
#               "localizacion_ulcera": "antepié plantar derecho",
#               "tiempo_evolucion": "3 semanas",
#               "hba1c": 8.5,
#               "fiebre": False,
#               "olor_presente": True,
#               "exudado_cantidad": "moderado"
#           }
#       }
#   )
#   print(respuesta.json()["analisis_ia"])
#
# ─────────────────────────────────────────────────────────────────────
