"""
╔══════════════════════════════════════════════════════════════════════╗
║  FLUJO INTEGRADO — Agente 4 → Agente 7                             ║
║  piediabetico.lat — Versión 1.0.0                                   ║
╠══════════════════════════════════════════════════════════════════════╣
║  Flujo completo de análisis de foto:                                ║
║                                                                     ║
║  1. Agente 4 (ONNX, ~100ms, gratis)                                ║
║     └── Clasifica: ¿hay úlcera o piel sana?                        ║
║         ├── Piel sana → responde sin llamar a Claude               ║
║         └── Úlcera → continúa al Agente 7                         ║
║                                                                     ║
║  2. Agente 7 (Claude Vision, ~3s, costo API)                       ║
║     └── Análisis clínico completo según perfil del usuario         ║
║                                                                     ║
║  Ventaja: ahorra hasta 90% de las llamadas a Claude API            ║
║  cuando los usuarios suben fotos que no son heridas.               ║
║                                                                     ║
║  Integración en main.py:                                           ║
║    from flujo_foto_integrado import router_flujo                    ║
║    app.include_router(router_flujo)                                 ║
║                                                                     ║
║  Endpoint disponible:                                              ║
║    POST /analizar-foto                                             ║
╚══════════════════════════════════════════════════════════════════════╝
"""

import logging
from typing import Optional
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

# Importar los dos agentes
from agente4_clasificador_ulcera import (
    ClasificadorInput,
    _inferir as clasificar_imagen,
)
from agente7_triage_multimodal import (
    TriageInput,
    DatosClinicosContexto,
    PerfilUsuario,
    ejecutar_triage,
    TriageOutput,
)

logger = logging.getLogger(__name__)

router_flujo = APIRouter(tags=["Flujo Integrado — Foto Completo"])

DISCLAIMER = (
    "⚠️ Análisis asistido por IA. No reemplaza el criterio clínico profesional."
)


# ─────────────────────────────────────────────────────────────────────
# SCHEMAS
# ─────────────────────────────────────────────────────────────────────

class FotoAnalisisInput(BaseModel):
    """
    Input único para el flujo completo de análisis de foto.
    Combina los parámetros del Agente 4 y el Agente 7.
    """
    imagen_base64: str = Field(
        ...,
        description="Foto de la herida o del pie en base64 (JPEG o PNG)."
    )
    perfil_usuario: PerfilUsuario = Field(
        ...,
        description="Perfil del usuario. Determina el lenguaje y estructura del análisis clínico."
    )
    datos_clinicos: DatosClinicosContexto = Field(
        default_factory=DatosClinicosContexto,
        description="Contexto clínico del paciente. Más datos = mejor análisis."
    )
    imagen_mime_type: str = Field(
        default="image/jpeg",
        description="Tipo MIME: image/jpeg o image/png"
    )
    umbral_ulcera: float = Field(
        default=0.35,
        ge=0.1, le=0.95,
        description=(
            "Umbral del clasificador para derivar al análisis completo. "
            "Default 0.35 (más sensible que 0.5 para uso clínico). "
            "Bajar aumenta sensibilidad, subir aumenta especificidad."
        )
    )
    forzar_analisis_completo: bool = Field(
        default=False,
        description=(
            "Si True, omite el Agente 4 y va directo al Agente 7. "
            "Útil para profesionales que siempre quieren el análisis completo."
        )
    )


class FotoAnalisisOutput(BaseModel):
    """
    Resultado completo del flujo de análisis de foto.
    """
    # ── Resultado del Agente 4 ────────────────────────────────────────
    clasificacion_realizada:   bool  = Field(..., description="Si se ejecutó el Agente 4")
    es_ulcera:                 bool  = Field(..., description="True si el modelo detectó úlcera")
    prob_ulcera:               float = Field(..., description="Probabilidad de úlcera (0 a 1)")
    clase_detectada:           str   = Field(..., description="'Úlcera detectada' o 'Piel sana'")

    # ── Resultado del Agente 7 ────────────────────────────────────────
    analisis_realizado:        bool          = Field(..., description="Si se ejecutó el Agente 7")
    analisis_clinico:          Optional[str] = Field(None, description="Análisis clínico de Claude Vision")
    tokens_utilizados:         Optional[int] = Field(None, description="Tokens consumidos en Claude API")
    motivo_sin_analisis:       Optional[str] = Field(None, description="Por qué no se hizo el análisis completo")

    # ── Metadatos ─────────────────────────────────────────────────────
    perfil_consultado:         str   = Field(..., description="Perfil del usuario")
    umbral_aplicado:           float = Field(..., description="Umbral de clasificación usado")
    modelo_clasificador:       str   = Field(..., description="Modelo del Agente 4")
    disclaimer:                str   = Field(..., description="Aviso clínico")


# ─────────────────────────────────────────────────────────────────────
# FLUJO PRINCIPAL
# ─────────────────────────────────────────────────────────────────────

def _ejecutar_flujo(datos: FotoAnalisisInput) -> FotoAnalisisOutput:
    """
    Orquesta el flujo Agente 4 → Agente 7.

    Decisión de derivación:
    - Si forzar_analisis_completo = True → saltea Agente 4, va directo a Agente 7
    - Si prob_ulcera >= umbral → ejecuta Agente 7
    - Si prob_ulcera < umbral → responde sin Agente 7
    """

    # ── PASO 1: Agente 4 (clasificador binario) ───────────────────────
    if datos.forzar_analisis_completo:
        # Profesional que siempre quiere análisis completo
        logger.info("[Flujo] Modo forzado — omitiendo Agente 4")
        clasificacion = {
            "es_ulcera": True,
            "prob_ulcera": 1.0,
            "prob_normal": 0.0,
            "confianza": 1.0,
            "clase": "Análisis forzado por profesional",
        }
        clasificacion_realizada = False
    else:
        logger.info("[Flujo] Ejecutando Agente 4 — clasificador binario")
        try:
            clasificacion = clasificar_imagen(datos.imagen_base64)
            clasificacion_realizada = True
            logger.info(
                f"[Flujo] Agente 4 → úlcera: {clasificacion['es_ulcera']}, "
                f"prob: {clasificacion['prob_ulcera']:.3f}"
            )
        except Exception as e:
            logger.warning(f"[Flujo] Agente 4 falló: {e}. Derivando al Agente 7 por seguridad.")
            # Si el clasificador falla, derivamos al Agente 7 por seguridad clínica
            clasificacion = {
                "es_ulcera": True,
                "prob_ulcera": 0.5,
                "prob_normal": 0.5,
                "confianza": 0.5,
                "clase": "Clasificación no disponible",
            }
            clasificacion_realizada = False

    # ── DECISIÓN: ¿derivar al Agente 7? ──────────────────────────────
    prob_ulcera  = clasificacion["prob_ulcera"]
    derivar      = datos.forzar_analisis_completo or (prob_ulcera >= datos.umbral_ulcera)

    # ── PASO 2: Agente 7 (Claude Vision) — solo si hay úlcera ─────────
    if derivar:
        logger.info(
            f"[Flujo] Derivando al Agente 7 — "
            f"prob_ulcera: {prob_ulcera:.3f} >= umbral: {datos.umbral_ulcera}"
        )
        try:
            triage_input = TriageInput(
                imagen_base64    = datos.imagen_base64,
                perfil_usuario   = datos.perfil_usuario,
                datos_clinicos   = datos.datos_clinicos,
                imagen_mime_type = datos.imagen_mime_type,
            )
            resultado_triage: TriageOutput = ejecutar_triage(triage_input)

            return FotoAnalisisOutput(
                clasificacion_realizada = clasificacion_realizada,
                es_ulcera               = clasificacion["es_ulcera"],
                prob_ulcera             = round(prob_ulcera, 4),
                clase_detectada         = clasificacion["clase"],
                analisis_realizado      = True,
                analisis_clinico        = resultado_triage.analisis_ia,
                tokens_utilizados       = resultado_triage.tokens_utilizados,
                motivo_sin_analisis     = None,
                perfil_consultado       = datos.perfil_usuario.value,
                umbral_aplicado         = datos.umbral_ulcera,
                modelo_clasificador     = "EfficientNet-B0 DFU v1.0 (ONNX)",
                disclaimer              = DISCLAIMER,
            )

        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"[Flujo] Agente 7 falló: {e}", exc_info=True)
            raise HTTPException(
                status_code=502,
                detail=f"Error en el análisis clínico con IA: {str(e)}"
            )

    else:
        # No hay úlcera detectada — responder sin Claude
        logger.info(
            f"[Flujo] Sin derivación — "
            f"prob_ulcera: {prob_ulcera:.3f} < umbral: {datos.umbral_ulcera}"
        )

        # Mensaje adaptado al perfil
        mensajes_sin_ulcera = {
            "paciente": (
                "**Lo que veo en tu foto:**\n"
                "No detecto señales claras de una herida abierta en esta imagen.\n\n"
                "**¿Qué tan urgente es?**\n"
                "🟢 PODÉS ESPERAR\n"
                "Por ahora no parece urgente. Seguí revisando tu pie diariamente.\n\n"
                "**Qué hacer ahora mismo:**\n"
                "1. Revisá el pie con buena luz, especialmente entre los dedos y la planta.\n"
                "2. Si ves algo que te preocupa, sacá otra foto más de cerca.\n"
                "3. Contale a tu médico en la próxima consulta si algo cambió.\n\n"
                "**Señal de alarma — consultá URGENTE si ves esto:**\n"
                "Si aparece enrojecimiento, hinchazón, herida abierta o sentís dolor, "
                "consultá ese mismo día."
            ),
            "podologo_enfermero": (
                "El clasificador automático no detectó señales de úlcera activa en esta imagen "
                f"(prob_ulcera: {prob_ulcera:.2f}). "
                "Si clínicamente sospechás una herida, usá el parámetro "
                "forzar_analisis_completo=true para ejecutar el análisis completo con IA."
            ),
            "infectologo": (
                f"Clasificador: piel sana (prob_ulcera: {prob_ulcera:.2f}, "
                f"umbral: {datos.umbral_ulcera}). "
                "No se derivó al análisis clínico completo. "
                "Activar forzar_analisis_completo=true si la imagen muestra infección."
            ),
            "diabetologo": (
                f"Clasificador: sin úlcera detectada (prob_ulcera: {prob_ulcera:.2f}). "
                "Imagen posiblemente de piel sana o zona sin lesión activa. "
                "Usar forzar_analisis_completo=true para análisis integral."
            ),
            "medico_general": (
                "La imagen no muestra señales claras de úlcera activa según el clasificador automático. "
                "Si clínicamente hay una herida, tomá una foto más cercana y con mejor iluminación, "
                "o activá el análisis completo."
            ),
        }

        perfil_key = datos.perfil_usuario.value
        mensaje    = mensajes_sin_ulcera.get(perfil_key, mensajes_sin_ulcera["paciente"])

        return FotoAnalisisOutput(
            clasificacion_realizada = clasificacion_realizada,
            es_ulcera               = False,
            prob_ulcera             = round(prob_ulcera, 4),
            clase_detectada         = "Piel sana",
            analisis_realizado      = False,
            analisis_clinico        = mensaje,
            tokens_utilizados       = 0,
            motivo_sin_analisis     = (
                f"Probabilidad de úlcera ({prob_ulcera:.2f}) "
                f"menor al umbral configurado ({datos.umbral_ulcera}). "
                "No se realizó análisis con Claude Vision."
            ),
            perfil_consultado       = perfil_key,
            umbral_aplicado         = datos.umbral_ulcera,
            modelo_clasificador     = "EfficientNet-B0 DFU v1.0 (ONNX)",
            disclaimer              = DISCLAIMER,
        )


# ─────────────────────────────────────────────────────────────────────
# ENDPOINTS
# ─────────────────────────────────────────────────────────────────────

@router_flujo.post(
    "/analizar-foto",
    response_model=FotoAnalisisOutput,
    summary="Flujo completo — Análisis de foto (Agente 4 → Agente 7)",
)
def api_analizar_foto(datos: FotoAnalisisInput):
    """
    **Flujo integrado de análisis fotográfico**

    Ejecuta automáticamente el pipeline completo:

    **Paso 1 — Agente 4 (Clasificador ONNX):**
    Detecta si hay una úlcera en la imagen en ~100ms sin costo de API.

    **Paso 2 — Agente 7 (Claude Vision):**
    Si hay úlcera, ejecuta el análisis clínico completo adaptado al perfil del usuario.

    **Optimización de costos:**
    Solo se llama a Claude API cuando el clasificador detecta una úlcera.
    Las fotos de piel sana, calzado o imágenes no clínicas se filtran automáticamente.

    **Parámetros clave:**
    - `umbral_ulcera`: 0.35 por defecto (más sensible para uso clínico)
    - `forzar_analisis_completo`: True para saltear el clasificador

    **Perfiles disponibles:**
    - `paciente` — lenguaje simple, semáforo verde/amarillo/rojo
    - `podologo_enfermero` — TIMERS, apósitos, conducta de curación
    - `infectologo` — IDSA, cobertura empírica, criterios de internación
    - `diabetologo` — Wagner, IWGDF, correlación metabólica
    - `medico_general` — señales de alarma, derivación

    **Disclaimer:** Herramienta de apoyo clínico. No reemplaza el criterio profesional.
    """
    try:
        return _ejecutar_flujo(datos)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"[Flujo] Error inesperado: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="Error interno en el análisis de foto.")


@router_flujo.get(
    "/analizar-foto/estado",
    summary="Estado del flujo integrado",
)
def estado_flujo():
    """
    Verifica el estado de ambos agentes del flujo.
    """
    import os

    modelo_onnx = os.getenv(
        "CLASIFICADOR_ONNX_PATH",
        "/opt/piediadbetico/modelos/dfu_efficientnet_b0.onnx"
    )
    api_key_ok = bool(os.getenv("ANTHROPIC_API_KEY"))

    return {
        "flujo":              "Agente 4 → Agente 7",
        "agente4_modelo":     modelo_onnx,
        "agente4_disponible": os.path.exists(modelo_onnx),
        "agente7_api_key":    "configurada" if api_key_ok else "NO CONFIGURADA",
        "agente7_modelo":     "claude-sonnet-4-6",
        "umbral_default":     0.35,
        "descripcion": (
            "El Agente 4 filtra imágenes sin úlcera (~100ms, sin costo). "
            "El Agente 7 analiza las imágenes con úlcera (~3s, costo API Claude)."
        ),
    }


# ─────────────────────────────────────────────────────────────────────
# INTEGRACIÓN EN main.py — DOS LÍNEAS
# ─────────────────────────────────────────────────────────────────────
#
# Agregar al inicio de main_final_completo.py:
#
#   from flujo_foto_integrado import router_flujo
#
# Agregar después de registrar los otros routers:
#
#   app.include_router(router_flujo)
#
# Endpoints que quedan disponibles:
#
#   POST /analizar-foto          ← flujo completo
#   GET  /analizar-foto/estado   ← verificar estado
#
# ─────────────────────────────────────────────────────────────────────
#
# EJEMPLO DE LLAMADA (frontend Next.js):
#
#   const respuesta = await fetch('/analizar-foto', {
#     method: 'POST',
#     headers: { 'Content-Type': 'application/json' },
#     body: JSON.stringify({
#       imagen_base64: imagenEnBase64,
#       perfil_usuario: 'podologo_enfermero',
#       umbral_ulcera: 0.35,
#       datos_clinicos: {
#         localizacion_ulcera: 'antepié plantar derecho',
#         tiempo_evolucion: '2 semanas',
#         hba1c: 8.5,
#         fiebre: false,
#         olor_presente: true,
#         exudado_cantidad: 'moderado'
#       }
#     })
#   });
#
#   const data = await respuesta.json();
#
#   if (data.analisis_realizado) {
#     mostrarAnalisisClinico(data.analisis_clinico);
#   } else {
#     mostrarMensajePielSana(data.analisis_clinico);
#   }
#
# ─────────────────────────────────────────────────────────────────────
